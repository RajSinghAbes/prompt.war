const taskInput = document.getElementById('task');
const taskList = document.getElementById('taskList');
const emptyMessage = document.getElementById('empty');
const message = document.getElementById('message');

async function showTasks() {
    try {
        const response = await fetch('/tasks');
        if (!response.ok) throw new Error('Could not load tasks');

        const tasks = await response.json();
        taskList.replaceChildren();

        tasks.forEach((task, index) => {
            const item = document.createElement('li');
            const taskText = document.createElement('span');
            taskText.textContent = task;

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.type = 'button';
            deleteButton.addEventListener('click', () => deleteTask(index));

            item.append(taskText, deleteButton);
            taskList.appendChild(item);
        });

        emptyMessage.hidden = tasks.length > 0;
        message.textContent = '';
    } catch (error) {
        message.textContent = error.message;
    }
}

async function addTask() {
    const task = taskInput.value.trim();
    if (!task) {
        message.textContent = 'Please enter a task.';
        taskInput.focus();
        return;
    }

    try {
        const response = await fetch('/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ task })
        });
        if (!response.ok) throw new Error('Could not add task');

        taskInput.value = '';
        await showTasks();
        taskInput.focus();
    } catch (error) {
        message.textContent = error.message;
    }
}

async function deleteTask(id) {
    try {
        const response = await fetch(`/tasks/${id}`, { method: 'DELETE' });
        if (!response.ok) throw new Error('Could not delete task');
        await showTasks();
    } catch (error) {
        message.textContent = error.message;
    }
}

document.getElementById('addButton').addEventListener('click', addTask);
taskInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') addTask();
});

showTasks();
